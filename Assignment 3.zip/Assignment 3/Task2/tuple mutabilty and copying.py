import copy
import sys
import time


print("=" * 60)
print("PART A: COMPLETE THE CODE")
print("=" * 60)

rows, cols = 3, 4

bad = [[0] * cols] * rows          # every row is the SAME list object
bad[0][1] = 7

# TODO 1: grid of zeros using list comprehension, every row a separate list
good = [[0] * cols for _ in range(rows)]
good[0][1] = 7

print("bad :", bad)
print("good:", good)
print(bad[0] is bad[1], good[0] is good[1])

# Tuples are immutable, so they can be used as dictionary keys
stops = {(13.0827, 80.2707): "Chennai Central", (13.0418, 80.2341): "T. Nagar"}
print(stops[(13.0418, 80.2341)])

# Try a list as a dictionary key -> error
print("\nTrying a list as a dictionary key:")
try:
    wrong = {[13.0418, 80.2341]: "T. Nagar"}
except TypeError as error:
    print("TypeError:", error)


print("\n" + "=" * 60)
print("PART B: IMPLEMENTATION TASKS")
print("=" * 60)

# 1. Each stop is a tuple (latitude, longitude), used as a dictionary key
print("\n1. Tuples as dictionary keys")
stop_names = {
    (13.0827, 80.2707): "Chennai Central",
    (13.0418, 80.2341): "T. Nagar",
    (13.0674, 80.2376): "Anna Nagar",
}
print("Number of stops:", len(stop_names))
print("Is (13.0674, 80.2376) a stop?", (13.0674, 80.2376) in stop_names)

# 2. Unpack tuples in a for loop
print("\n2. Unpacking tuples in a for loop")
for (lat, lon), name in stop_names.items():
    print(name, "-> latitude =", lat, ", longitude =", lon)

# 3. Zone grid created correctly, then update passenger counts
print("\n3. Correct zone grid")
zone_grid = [[0] * cols for _ in range(rows)]
zone_grid[1][2] += 25      # 25 passengers boarded in zone (1, 2)
zone_grid[2][0] += 10
for row in zone_grid:
    print(row)

# 4. Aliasing, shallow copy, deep copy
print("\n4. Aliasing, shallow copy and deep copy")
original = [[1, 2], [3, 4]]

alias = original                      # same object, no copy at all
shallow1 = copy.copy(original)        # new outer list, SAME inner lists
shallow2 = original[:]                # slicing also gives a shallow copy
deep = copy.deepcopy(original)        # new outer list AND new inner lists

original[0][0] = 99                   # change an INNER list
print("original :", original)
print("alias    :", alias,    "  <- changed (same object)")
print("shallow1 :", shallow1, "  <- changed (shares inner lists)")
print("shallow2 :", shallow2, "  <- changed (shares inner lists)")
print("deep     :", deep,     " <- NOT changed (fully independent)")

original.append([5, 6])               # change the OUTER list
print("\nAfter original.append([5, 6]):")
print("alias    :", alias,    "  <- changed")
print("shallow1 :", shallow1, "  <- NOT changed (outer list is separate)")
print("deep     :", deep,     "  <- NOT changed")

# 5. Function changing a list argument changes the caller's list
print("\n5. Function that changes a list argument")


def add_passengers(counts):
    counts[0] = counts[0] + 100       # changes the SAME list the caller has


def add_passengers_safe(counts):
    counts = counts[:]                # work on a copy
    counts[0] = counts[0] + 100
    return counts


morning = [10, 20, 30]
add_passengers(morning)
print("After add_passengers(morning):", morning, "<- caller's list changed")

evening = [10, 20, 30]
new_list = add_passengers_safe(evening)
print("After add_passengers_safe(evening):", evening, "<- unchanged")
print("Returned new list:", new_list)


print("\n" + "=" * 60)
print("PART C: EXPERIMENTAL INVESTIGATION")
print("=" * 60)

# 1. The bug and its correction with is and id()
print("\n1. Bug and correction using is and id()")
bad_grid = [[0] * 3] * 3
good_grid = [[0] * 3 for _ in range(3)]

print("BAD grid:")
for i in range(3):
    print("  row", i, "id =", id(bad_grid[i]))
print("  bad_grid[0] is bad_grid[1]:", bad_grid[0] is bad_grid[1])
print("  bad_grid[1] is bad_grid[2]:", bad_grid[1] is bad_grid[2])

print("GOOD grid:")
for i in range(3):
    print("  row", i, "id =", id(good_grid[i]))
print("  good_grid[0] is good_grid[1]:", good_grid[0] is good_grid[1])
print("  good_grid[1] is good_grid[2]:", good_grid[1] is good_grid[2])

bad_grid[0][0] = 5
good_grid[0][0] = 5
print("After setting [0][0] = 5:")
print("  bad_grid :", bad_grid)
print("  good_grid:", good_grid)

# 2. Memory of a list and tuple of 1,000,000 values
print("\n2. Memory: list vs tuple of 1,000,000 values")
N = 1000000
big_list = list(range(N))
big_tuple = tuple(range(N))
size_list = sys.getsizeof(big_list)
size_tuple = sys.getsizeof(big_tuple)
print("list  size :", size_list, "bytes")
print("tuple size :", size_tuple, "bytes")
print("Difference :", size_list - size_tuple, "bytes")
print("(getsizeof counts the container only, not the int objects inside.)")

# 3. Time creating and indexing a tuple and a list
print("\n3. Timing: create and index (1,000,000 values)")

t = time.perf_counter()
for _ in range(10):
    temp = list(range(N))
time_create_list = (time.perf_counter() - t) / 10

t = time.perf_counter()
for _ in range(10):
    temp = tuple(range(N))
time_create_tuple = (time.perf_counter() - t) / 10

t = time.perf_counter()
for i in range(N):
    value = big_list[i]
time_index_list = time.perf_counter() - t

t = time.perf_counter()
for i in range(N):
    value = big_tuple[i]
time_index_tuple = time.perf_counter() - t

print("Create list  : %.5f s" % time_create_list)
print("Create tuple : %.5f s" % time_create_tuple)
print("Index list   : %.5f s (1,000,000 lookups)" % time_index_list)
print("Index tuple  : %.5f s (1,000,000 lookups)" % time_index_tuple)

# 4. List stored inside a tuple
print("\n4. Changing a list stored inside a tuple")
stop = ("T. Nagar", [10, 20, 30])      # tuple holding a name and a list
print("Before:", stop, " id of list =", id(stop[1]))

stop[1].append(40)                    # changing the LIST inside: allowed
print("After stop[1].append(40):", stop, " id of list =", id(stop[1]))

try:
    stop[0] = "Anna Nagar"            # changing the tuple itself: not allowed
except TypeError as error:
    print("stop[0] = ... -> TypeError:", error)

try:
    stop[1] += [50]                   # += tries to REASSIGN stop[1]
except TypeError as error:
    print("stop[1] += [50] -> TypeError:", error)
print("But the list was still extended:", stop)

try:
    hash(stop)
except TypeError as error:
    print("hash(stop) -> TypeError:", error)


print("\n" + "=" * 60)
print("PART D: SPARSE GRID USING A DICTIONARY KEYED BY (row, col)")
print("=" * 60)

sparse = {}                           # only zones that have passengers


def board(grid, r, c, count):
    grid[(r, c)] = grid.get((r, c), 0) + count


board(sparse, 1, 2, 25)
board(sparse, 2, 0, 10)
board(sparse, 1, 2, 5)                # same zone again, adds up to 30
print("Sparse grid:", sparse)
print("Passengers in zone (1, 2):", sparse.get((1, 2), 0))
print("Passengers in zone (0, 0):", sparse.get((0, 0), 0), "(not stored)")

for (r, c), count in sparse.items():
    print("Zone row", r, "col", c, "->", count, "passengers")


R, C = 1000, 1000
full_grid = [[0] * C for _ in range(R)]
sparse_big = {}
for k in range(200):                  # only 200 busy zones
    sparse_big[(k * 5, k * 3)] = k + 1

size_full = sys.getsizeof(full_grid) + sum(sys.getsizeof(row) for row in full_grid)
size_sparse = sys.getsizeof(sparse_big)
print("\nGrid 1000 x 1000 (1,000,000 zones), 200 busy zones:")
print("List of lists size :", size_full, "bytes")
print("Dictionary size    :", size_sparse, "bytes")

t = time.perf_counter()
for _ in range(1000000):
    value = full_grid[500][500]
time_list_access = time.perf_counter() - t

t = time.perf_counter()
for _ in range(1000000):
    value = sparse_big.get((500, 300), 0)
time_dict_access = time.perf_counter() - t
print("1,000,000 accesses, list of lists : %.4f s" % time_list_access)
print("1,000,000 accesses, dictionary    : %.4f s" % time_dict_access)