import random
import sys
import time
import tracemalloc

DAY_ORDER = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

# ===============================================================
# PART A: THE NESTED STRUCTURE (6 trains, illustrative times)
# ===============================================================
# timetable[train_number] = {
#     "name": str,
#     "stops": [(station, arrival, departure), ...],   # list of tuples, in route order
#     "days": {"Mon", "Tue", ...}                      # set of running days
# }
# "--" means: no arrival at the first station / no departure at the last station.

timetable = {
    "12007": {
        "name": "Chennai - Bengaluru Shatabdi",
        "stops": [("Chennai Central", "--", "06:00"),
                  ("Katpadi Jn", "07:35", "07:37"),
                  ("KSR Bengaluru", "11:00", "--")],
        "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat"},
    },
    "12675": {
        "name": "Kovai Express",
        "stops": [("Chennai Central", "--", "06:15"),
                  ("Katpadi Jn", "08:00", "08:02"),
                  ("Salem Jn", "10:30", "10:35"),
                  ("Erode Jn", "11:25", "11:30"),
                  ("Coimbatore Jn", "13:15", "--")],
        "days": set(DAY_ORDER),
    },
    "12607": {
        "name": "Lalbagh Express",
        "stops": [("Chennai Central", "--", "15:30"),
                  ("Katpadi Jn", "17:10", "17:12"),
                  ("KSR Bengaluru", "21:15", "--")],
        "days": set(DAY_ORDER),
    },
    "12609": {
        "name": "Mysuru Express",
        "stops": [("Chennai Central", "--", "13:30"),
                  ("Katpadi Jn", "15:08", "15:10"),
                  ("KSR Bengaluru", "18:35", "18:45"),
                  ("Mysuru Jn", "21:00", "--")],
        "days": {"Tue", "Thu", "Sat"},
    },
    "12639": {
        "name": "Brindavan Express",
        "stops": [("Chennai Central", "--", "07:50"),
                  ("Katpadi Jn", "09:40", "09:42"),
                  ("KSR Bengaluru", "13:00", "--")],
        "days": set(DAY_ORDER),
    },
    "12633": {
        "name": "Kanyakumari Express",
        "stops": [("Chennai Egmore", "--", "17:30"),
                  ("Tiruchirappalli", "23:45", "23:50"),
                  ("Madurai Jn", "02:30", "02:35"),
                  ("Kanyakumari", "07:00", "--")],
        "days": {"Mon", "Wed"},
    },
}


def print_timetable(tt):
    """Print the whole timetable neatly."""
    for number in sorted(tt):
        info = tt[number]
        days = ", ".join(sorted(info["days"], key=DAY_ORDER.index))
        print("Train %s - %s" % (number, info["name"]))
        print("  Runs on: " + days)
        print("  %-18s %-9s %-9s" % ("Station", "Arrives", "Departs"))
        for station, arrival, departure in info["stops"]:     # unpack the tuple
            print("  %-18s %-9s %-9s" % (station, arrival, departure))
        print()


# ===============================================================
# PART B: QUERIES
# ===============================================================

def trains_at_scan(tt, station, day):
    """No index: look through every stop of every train."""
    found = []
    for number, info in tt.items():
        if day in info["days"]:
            for stop_station, arrival, departure in info["stops"]:
                if stop_station == station:
                    found.append((number, info["name"], arrival, departure))
    return found


def sort_by_departure(found):
    """Sort results by departure time. If a train ends here, use arrival time."""
    return sorted(found, key=lambda r: r[3] if r[3] != "--" else r[2])


def build_index(tt):
    """station -> list of (train number, arrival, departure)."""
    index = {}
    for number, info in tt.items():
        for station, arrival, departure in info["stops"]:
            index.setdefault(station, []).append((number, arrival, departure))
    return index


def trains_at_index(tt, index, station, day):
    """With index: only look at the trains that stop at this station."""
    found = []
    for number, arrival, departure in index.get(station, []):
        if day in tt[number]["days"]:
            found.append((number, tt[number]["name"], arrival, departure))
    return found


def build_flat(tt):
    """Alternative design: one flat list of (train, station, arr, dep, days)."""
    flat = []
    for number, info in tt.items():
        for station, arrival, departure in info["stops"]:
            flat.append((number, station, arrival, departure, info["days"]))
    return flat


def trains_at_flat(flat, names, station, day):
    """Scan the whole flat list for every query."""
    found = []
    for number, stop_station, arrival, departure, days in flat:
        if stop_station == station and day in days:
            found.append((number, names[number], arrival, departure))
    return found


def show_result(found):
    if len(found) == 0:
        print("  (no trains)")
    for number, name, arrival, departure in found:
        print("  %s %-30s arr %-6s dep %-6s" % (number, name, arrival, departure))


print("=" * 66)
print("PART A: TIMETABLE (6 trains)")
print("=" * 66)
print_timetable(timetable)

print("=" * 66)
print("PART B: QUERIES")
print("=" * 66)

# Reaching the departure time of the third station of a train
third = timetable["12675"]["stops"][2][2]
print("Departure from the 3rd station of train 12675:")
print('  timetable["12675"]["stops"][2][2] ->', third,
      "(", timetable["12675"]["stops"][2][0], ")")

print("\nTrains stopping at Katpadi Jn on Mon, sorted by departure time:")
show_result(sort_by_departure(trains_at_scan(timetable, "Katpadi Jn", "Mon")))

print("\nTrains stopping at Katpadi Jn on Tue (Mysuru Express now runs):")
show_result(sort_by_departure(trains_at_scan(timetable, "Katpadi Jn", "Tue")))

index = build_index(timetable)
print("\nIndex (station -> number of trains):")
for station in index:
    print("  %-18s %d" % (station, len(index[station])))

print("\nSame query using the index (Katpadi Jn, Mon):")
show_result(sort_by_departure(trains_at_index(timetable, index, "Katpadi Jn", "Mon")))

# ===============================================================
# PART C: EDGE-CASE TESTS
# ===============================================================
print("\n" + "=" * 66)
print("PART C: EDGE-CASE TESTS")
print("=" * 66)

names = {number: info["name"] for number, info in timetable.items()}
flat = build_flat(timetable)

tests = [
    ("unknown station",             "Atlantis Jn",     "Mon"),
    ("train not running on day",    "Mysuru Jn",       "Mon"),
    ("train not running (Katpadi)", "Katpadi Jn",      "Sun"),
    ("invalid day",                 "Katpadi Jn",      "Funday"),
    ("first station of route",      "Chennai Central", "Wed"),
    ("last station of route",       "KSR Bengaluru",   "Sat"),
]
for label, station, day in tests:
    a = sort_by_departure(trains_at_scan(timetable, station, day))
    b = sort_by_departure(trains_at_index(timetable, index, station, day))
    c = sort_by_departure(trains_at_flat(flat, names, station, day))
    print("\n%s: %s on %s  (%d trains; scan/index/flat agree: %s)" %
          (label, station, day, len(a), a == b == c))
    show_result(a)

# ===============================================================
# PART D: EXPERIMENT WITH 100, 1000, 10000 TRAINS
# ===============================================================
print("\n" + "=" * 66)
print("PART D: EXPERIMENT")
print("=" * 66)

random.seed(7)
STATION_POOL = ["S" + str(i) for i in range(200)]       # 200 different stations


def random_time():
    return "%02d:%02d" % (random.randint(0, 23), random.randint(0, 59))


def make_timetable(n):
    tt = {}
    for i in range(n):
        stations = random.sample(STATION_POOL, random.randint(8, 15))
        stops = []
        for j in range(len(stations)):
            arrival = "--" if j == 0 else random_time()
            departure = "--" if j == len(stations) - 1 else random_time()
            stops.append((stations[j], arrival, departure))
        days = set(random.sample(DAY_ORDER, random.randint(3, 7)))
        tt[str(10000 + i)] = {"name": "Train " + str(i), "stops": stops, "days": days}
    return tt


def time_per_query(function, stations, repeats):
    start = time.perf_counter()
    for _ in range(repeats):
        for station in stations:
            function(station)
    total = time.perf_counter() - start
    return total / (repeats * len(stations))


query_stations = random.sample(STATION_POOL, 20)

print("\n1. Average time per query (microseconds)")
print("%-8s %-9s %-14s %-14s %-14s %-9s" %
      ("trains", "stops", "nested scan", "flat scan", "with index", "speed-up"))

memory_rows = []
for n in [100, 1000, 10000]:
    # --- memory (measured with tracemalloc, separate from timing) ---
    tracemalloc.start()
    tt = make_timetable(n)
    mem_tt = tracemalloc.get_traced_memory()[0]
    idx = build_index(tt)
    mem_both = tracemalloc.get_traced_memory()[0]
    fl = build_flat(tt)
    mem_all = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()
    mem_index = mem_both - mem_tt
    mem_flat = mem_all - mem_both
    total_stops = len(fl)

    nm = {number: info["name"] for number, info in tt.items()}

    # --- timing ---
    start = time.perf_counter()
    build_index(tt)
    build_time = time.perf_counter() - start

    reps_scan = 1 if n >= 1000 else 20
    t_nested = time_per_query(lambda s: trains_at_scan(tt, s, "Mon"),
                              query_stations, reps_scan)
    t_flat = time_per_query(lambda s: trains_at_flat(fl, nm, s, "Mon"),
                            query_stations, reps_scan)
    t_index = time_per_query(lambda s: trains_at_index(tt, idx, s, "Mon"),
                             query_stations, 50)

    # all three designs must give the same answers
    for s in query_stations:
        r1 = sort_by_departure(trains_at_scan(tt, s, "Mon"))
        r2 = sort_by_departure(trains_at_index(tt, idx, s, "Mon"))
        r3 = sort_by_departure(trains_at_flat(fl, nm, s, "Mon"))
        assert r1 == r2 == r3

    print("%-8d %-9d %-14.1f %-14.1f %-14.1f %-9.0f" %
          (n, total_stops, t_nested * 1e6, t_flat * 1e6, t_index * 1e6,
           t_nested / t_index))
    memory_rows.append((n, mem_tt, mem_index, mem_flat, build_time))

print("\n(all three designs returned identical results for every test query)")

print("\n2. Memory (bytes, measured with tracemalloc) and index build time")
print("%-8s %-14s %-14s %-9s %-14s %-12s" %
      ("trains", "timetable", "index (extra)", "index %", "flat list", "build index"))
for n, mem_tt, mem_index, mem_flat, build_time in memory_rows:
    print("%-8d %-14d %-14d %-9.1f %-14d %-.5f s" %
          (n, mem_tt, mem_index, 100.0 * mem_index / mem_tt, mem_flat, build_time))