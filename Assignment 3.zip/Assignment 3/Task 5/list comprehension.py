import sys
import time
import random

# Sample readings (includes sensor errors above 50 or below -50)
readings = [4.5, 5.0, 60.0, 7.5, -70.0, 9.2, 1.5, 3.0, 8.0, 55.5, 2.0, -3.0]

# ---------------------------------------------------------
# PART 1: for loop with append
# ---------------------------------------------------------
def clean_loop(data):
    celsius = []
    fahrenheit = []
    for c in data:
        if -50 <= c <= 50:
            celsius.append(c)
            fahrenheit.append(c * 9 / 5 + 32)
    return celsius, fahrenheit

# ---------------------------------------------------------
# PART 2: list comprehensions with conditions
# ---------------------------------------------------------
def clean_comp(data):
    celsius = [c for c in data if -50 <= c <= 50]
    fahrenheit = [c * 9 / 5 + 32 for c in data if -50 <= c <= 50]
    return celsius, fahrenheit

# ---------------------------------------------------------
# PART 3: map() and filter() with lambda
# ---------------------------------------------------------
def clean_map(data):
    celsius = list(filter(lambda c: -50 <= c <= 50, data))
    fahrenheit = list(map(lambda c: c * 9 / 5 + 32, celsius))
    return celsius, fahrenheit

# ---------------------------------------------------------
# PART 4: alarm minutes using enumerate()
# (minute numbers start at 1; valid readings outside 2-8 C)
# ---------------------------------------------------------
def alarm_minutes(data):
    alarms = []
    for minute, c in enumerate(data, start=1):
        if -50 <= c <= 50 and (c < 2 or c > 8):
            alarms.append(minute)
    return alarms

print("=== PART 1-4: Results on sample data ===")
c1, f1 = clean_loop(readings)
c2, f2 = clean_comp(readings)
c3, f3 = clean_map(readings)
print("Loop          C:", c1)
print("Loop          F:", f1)
print("Comprehension C:", c2)
print("map/filter    C:", c3)
print("Alarm minutes  :", alarm_minutes(readings))

# ---------------------------------------------------------
# PART 5: Verify the three versions give identical results
# ---------------------------------------------------------
print("\n=== PART 5: Verification ===")
print("Celsius identical   :", c1 == c2 == c3)
print("Fahrenheit identical:", f1 == f2 == f3)

# ---------------------------------------------------------
# PART 6: Dictionary and set comprehensions
# ---------------------------------------------------------
# Dictionary: minute -> Celsius, for valid readings only
minute_to_temp = {m: c for m, c in enumerate(readings, start=1) if -50 <= c <= 50}
# Set: unique valid readings
unique_valid = {c for c in readings if -50 <= c <= 50}

print("\n=== PART 6: Dict and set comprehensions ===")
print("Dict (minute -> C):", minute_to_temp)
print("Set (unique valid):", sorted(unique_valid))

# ---------------------------------------------------------
# PART 7: Test with all-valid and all-invalid readings
# ---------------------------------------------------------
print("\n=== PART 7: Edge cases ===")
all_valid = [1.0, 5.0, 10.0, -20.0]
all_invalid = [51.0, -51.0, 100.0, -80.0]
empty = []

for name, data in [("All valid", all_valid), ("All invalid", all_invalid), ("Empty", empty)]:
    a, _ = clean_loop(data)
    b, _ = clean_comp(data)
    d, _ = clean_map(data)
    print(f"{name:12}: loop={a} | same in all three: {a == b == d}")

# ---------------------------------------------------------
# PART 8: Timing the three versions
# ---------------------------------------------------------
print("\n=== PART 8: Timing (seconds) ===")
print(f"{'n':>9} | {'loop':>9} | {'comprehension':>13} | {'map/filter':>10}")
for n in [10000, 100000, 1000000]:
    data = [random.uniform(-60, 60) for _ in range(n)]

    start = time.perf_counter()
    clean_loop(data)
    t_loop = time.perf_counter() - start

    start = time.perf_counter()
    clean_comp(data)
    t_comp = time.perf_counter() - start

    start = time.perf_counter()
    clean_map(data)
    t_map = time.perf_counter() - start

    print(f"{n:>9} | {t_loop:>9.4f} | {t_comp:>13.4f} | {t_map:>10.4f}")

# ---------------------------------------------------------
# PART 9: Memory - list comprehension vs generator expression
# ---------------------------------------------------------
print("\n=== PART 9: Memory (bytes) ===")
print(f"{'n':>9} | {'list comp':>12} | {'generator':>10}")
for n in [10000, 100000, 1000000]:
    data = [random.uniform(-60, 60) for _ in range(n)]
    as_list = [c for c in data if -50 <= c <= 50]
    as_gen = (c for c in data if -50 <= c <= 50)
    print(f"{n:>9} | {sys.getsizeof(as_list):>12} | {sys.getsizeof(as_gen):>10}")

# ---------------------------------------------------------
# PART 10: Alternative - generator expression
# ---------------------------------------------------------
print("\n=== PART 10: Generator expression ===")
total_list = sum([c for c in readings if -50 <= c <= 50])   # builds a list first
total_gen = sum(c for c in readings if -50 <= c <= 50)      # no list is built
print("Sum using list     :", total_list)
print("Sum using generator:", total_gen)
print("Same result        :", total_list == total_gen)