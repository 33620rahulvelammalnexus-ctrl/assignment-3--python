import random
import time
import tracemalloc

# ===============================================================
# STAGE 1 - REQUIREMENTS (measurable statements)
# ===============================================================
# INPUT : a list of contacts from several sources (phone 1, phone 2, SIM).
#         Each contact is a dictionary:
#         {"name": str or None, "numbers": [str, ...], "emails": [str, ...]}
#         Any field may be missing, empty or None.
# OUTPUT: a list of records, one per person:
#         {"name": ..., "aliases": [...], "numbers": [...], "emails": [...]}
#
# SAME-PERSON RULE: two contacts are the same person if they share at least
# one NORMALISED number or one NORMALISED e-mail (directly, or through a chain
# of other contacts). A name on its own NEVER merges two contacts.
#
# R1  Every contact with a name, number or e-mail ends up in exactly one record.
# R2  Contacts that share a normalised number or e-mail are in the same record.
# R3  No number or e-mail is lost, and no number appears in two records.
# R4  The same number in different formats gives the same key.
# R5  Two contacts with the same name but no shared number/e-mail stay separate.
# R6  Missing, empty or None fields never crash the program.
# R7  100,000 contacts are merged in under 5 seconds, and the time per contact
#     grows by less than 5 times when n grows 100 times (a linear algorithm keeps
#     it about constant; a quadratic one would make it 100 times larger).

TITLES = {"dr", "mr", "mrs", "ms", "miss", "shri", "smt", "prof", "sri"}


# ===============================================================
# STAGE 2 - DESIGN: NORMALISATION
# ===============================================================

def normalise_number(raw):
    """Keep only the digits; keep the last 10 digits (drops +91, 0091, 0).
    Returns None if there are no digits."""
    if raw is None:
        return None
    digits = ""
    for ch in str(raw):
        if ch.isdigit():
            digits += ch
    if digits == "":
        return None
    if len(digits) > 10:
        digits = digits[-10:]
    return digits


def normalise_email(raw):
    """Lower-case and strip spaces. Returns None if it does not look like an e-mail."""
    if raw is None:
        return None
    email = str(raw).strip().lower()
    if "@" not in email:
        return None
    return email


def normalise_name(raw):
    """Lower-case, remove punctuation, drop leading titles (Dr., Mr., ...)."""
    if raw is None:
        return ""
    cleaned = ""
    for ch in str(raw).lower():
        if ch.isalnum() or ch in "'-":
            cleaned += ch
        else:
            cleaned += " "
    words = cleaned.split()
    while len(words) > 0 and words[0] in TITLES:
        words.pop(0)
    return " ".join(words)


def prepare(contact):
    """Normalise one contact. Works even if fields are missing or None."""
    name = normalise_name(contact.get("name"))
    numbers = set()
    for raw in contact.get("numbers") or []:
        number = normalise_number(raw)
        if number is not None:
            numbers.add(number)
    emails = set()
    for raw in contact.get("emails") or []:
        email = normalise_email(raw)
        if email is not None:
            emails.add(email)
    return name, numbers, emails


# ===============================================================
# STAGE 2 - DESIGN: MERGING WITH A DICTIONARY
# ===============================================================
# owner  : dictionary  normalised number / e-mail  ->  group id
# groups : dictionary  group id -> {"names": set, "numbers": set, "emails": set}
#
# PSEUDOCODE
#   owner <- empty dictionary ; groups <- empty dictionary
#   FOR EACH contact
#       name, numbers, emails <- normalise(contact)
#       keys <- numbers UNION emails
#       IF name is empty AND keys is empty THEN skip the contact
#       found <- { owner[k] : k in keys AND k in owner }
#       IF found is empty THEN create a new empty group g
#       ELSE g <- smallest id in found
#            FOR EACH other group in found: move its data into g
#                                           and point its keys to g
#       add name, numbers, emails to group g
#       FOR EACH k in keys: owner[k] <- g
#   RETURN the groups as sorted records

def make_records(groups):
    """Turn groups into a sorted list of output records."""
    records = []
    for g in groups:
        if len(g["names"]) > 0:
            display = max(g["names"], key=lambda s: (len(s), s)).title()
        else:
            display = "(no name)"
        records.append({"name": display,
                        "aliases": sorted(g["names"]),
                        "numbers": sorted(g["numbers"]),
                        "emails": sorted(g["emails"])})
    records.sort(key=lambda r: (r["name"], r["numbers"], r["emails"]))
    return records


def merge_with_dictionary(contacts):
    owner = {}
    groups = {}
    next_id = 0
    for contact in contacts:
        name, numbers, emails = prepare(contact)
        keys = numbers | emails
        if name == "" and len(keys) == 0:
            continue                                   # nothing useful in it

        found = set()
        for key in keys:
            if key in owner:
                found.add(owner[key])

        if len(found) == 0:
            gid = next_id
            next_id += 1
            groups[gid] = {"names": set(), "numbers": set(), "emails": set()}
        else:
            gid = min(found)
            for other in found:
                if other != gid:                       # join two groups into one
                    old = groups.pop(other)
                    groups[gid]["names"] |= old["names"]
                    groups[gid]["numbers"] |= old["numbers"]
                    groups[gid]["emails"] |= old["emails"]
                    for key in old["numbers"] | old["emails"]:
                        owner[key] = gid

        group = groups[gid]
        if name != "":
            group["names"].add(name)
        group["numbers"] |= numbers
        group["emails"] |= emails
        for key in keys:
            owner[key] = gid

    return make_records(list(groups.values()))


# ===============================================================
# ALTERNATIVE: COMPARE EVERY PAIR OF CONTACTS
# ===============================================================

def merge_with_pairs(contacts):
    people = []
    for contact in contacts:
        name, numbers, emails = prepare(contact)
        if name == "" and len(numbers) + len(emails) == 0:
            continue
        people.append((name, numbers, emails, numbers | emails))

    n = len(people)
    parent = list(range(n))            # union-find: parent[i] = leader of i's group

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i in range(n):
        keys_i = people[i][3]
        for j in range(i + 1, n):                      # every pair (i, j)
            if not keys_i.isdisjoint(people[j][3]):    # share a number or e-mail?
                a = find(i)
                b = find(j)
                if a != b:
                    parent[b] = a

    groups = {}
    for i in range(n):
        root = find(i)
        if root not in groups:
            groups[root] = {"names": set(), "numbers": set(), "emails": set()}
        if people[i][0] != "":
            groups[root]["names"].add(people[i][0])
        groups[root]["numbers"] |= people[i][1]
        groups[root]["emails"] |= people[i][2]
    return make_records(list(groups.values()))


# ===============================================================
# HELPERS FOR OUTPUT AND CHECKING
# ===============================================================

def show_number(number):
    if len(number) == 10:
        return "+91 " + number[:5] + " " + number[5:]
    return number


def print_records(records):
    for r in records:
        numbers = ", ".join(show_number(n) for n in r["numbers"]) or "-"
        emails = ", ".join(r["emails"]) or "-"
        print("  %-14s numbers: %-56s emails: %s" % (r["name"], numbers, emails))


def name_clashes(records):
    """Names shared by two or more DIFFERENT records (possible duplicates to review)."""
    seen = {}
    for r in records:
        for alias in r["aliases"]:
            seen.setdefault(alias, []).append(r)
    clashes = {}
    for alias in seen:
        if len(seen[alias]) > 1:
            clashes[alias] = len(seen[alias])
    return clashes


def check_no_loss(contacts, records):
    """R1/R3: every normalised number/e-mail is present, and none is repeated."""
    in_numbers = set()
    in_emails = set()
    for c in contacts:
        name, numbers, emails = prepare(c)
        in_numbers |= numbers
        in_emails |= emails
    out_numbers = []
    out_emails = []
    for r in records:
        out_numbers += r["numbers"]
        out_emails += r["emails"]
    same_sets = (set(out_numbers) == in_numbers and set(out_emails) == in_emails)
    no_repeat = (len(out_numbers) == len(set(out_numbers))
                 and len(out_emails) == len(set(out_emails)))
    return same_sets and no_repeat


print("=" * 70)
print("STAGE 3 - TEST 1: NORMALISATION")
print("=" * 70)

formats = ["+91 98400 12345", "9840012345", "098400-12345", "+91-98400-12345",
           "0091 9840012345", "(+91) 98400 12345", "98400 12345"]
print("Number formats -> key:")
all_same = True
for f in formats:
    key = normalise_number(f)
    print("  %-22s -> %s" % (repr(f), key))
    if key != "9840012345":
        all_same = False
print("All formats give the same key:", all_same)

print("\nBad or unusual numbers:")
for f in ["", None, "abc", "---", "100", 9840012345]:
    print("  %-14s -> %s" % (repr(f), normalise_number(f)))

print("\nNames:")
for f in ["Dr. Ravi", "  RAVI   KUMAR ", "Smt. Priya  Sharma", "Dr.", None, "O'Brien",
          "Anne-Marie"]:
    print("  %-22s -> %s" % (repr(f), repr(normalise_name(f))))

print("\nE-mails:")
for f in ["Priya@Mail.com", "  ravi@mail.com ", "not-an-email", "", None]:
    print("  %-20s -> %s" % (repr(f), normalise_email(f)))

# ---------------------------------------------------------------
print("\n" + "=" * 70)
print("STAGE 3 - TEST 2: SMALL LIST MERGED BY HAND")
print("=" * 70)

small = [
    {"source": "phone1", "name": "Dr. Ravi",     "numbers": ["+91 98400 12345"],                "emails": []},
    {"source": "phone2", "name": "ravi kumar",   "numbers": ["9840012345", "044-2345 6789"],    "emails": ["ravi@mail.com"]},
    {"source": "sim",    "name": "Ravi K",       "numbers": ["098400-12345"],                   "emails": []},
    {"source": "phone1", "name": "Priya Sharma", "numbers": ["98765 43210"],                    "emails": ["priya@mail.com"]},
    {"source": "phone2", "name": "PRIYA SHARMA", "numbers": ["+919876543210"],                  "emails": ["Priya@Mail.com"]},
    {"source": "phone1", "name": "Ravi Kumar",   "numbers": ["99999 88888"],                    "emails": []},
    {"source": "sim",    "name": "Anita",        "numbers": [],                                 "emails": ["anita@mail.com"]},
    {"source": "phone2", "name": "Anita Das",    "numbers": [],                                 "emails": ["ANITA@mail.com"]},
    {"source": "sim",    "name": None,           "numbers": ["+91 90000 11111"],                "emails": []},
    {"source": "phone1", "name": "Dr. Ravi",     "numbers": ["+91-98400-12345", "98400 54321"], "emails": []},
    {"source": "sim",    "name": "Suresh",       "numbers": [],                                 "emails": []},
    {"source": "sim",    "name": None,           "numbers": [None, ""],                        "emails": [""]},
    {"source": "phone2", "name": "Meena"},
]

print("Input: %d contacts" % len(small))

# Merged by hand (see the explanation): 13 contacts -> 7 people
expected = [
    {"name": "(no name)",    "numbers": ["9000011111"],                                "emails": []},
    {"name": "Anita Das",    "numbers": [],                                            "emails": ["anita@mail.com"]},
    {"name": "Meena",        "numbers": [],                                            "emails": []},
    {"name": "Priya Sharma", "numbers": ["9876543210"],                                "emails": ["priya@mail.com"]},
    {"name": "Ravi Kumar",   "numbers": ["4423456789", "9840012345", "9840054321"],    "emails": ["ravi@mail.com"]},
    {"name": "Ravi Kumar",   "numbers": ["9999988888"],                                "emails": []},
    {"name": "Suresh",       "numbers": [],                                            "emails": []},
]

merged = merge_with_dictionary(small)
print("Output: %d records\n" % len(merged))
print_records(merged)

simple_view = []
for r in merged:
    simple_view.append({"name": r["name"], "numbers": r["numbers"], "emails": r["emails"]})
hand_ok = (simple_view == expected)
print("\nMatches the hand-merged answer:", hand_ok)
print("Pairwise method gives the same records:", merge_with_pairs(small) == merged)
print("No number/e-mail lost or repeated:", check_no_loss(small, merged))

clashes = name_clashes(merged)
print("\nTwo 'Ravi Kumar' records stay separate (different numbers): ",
      len([r for r in merged if r["name"] == "Ravi Kumar"]) == 2)
print("Possible duplicates for the user to review (same name, NOT merged):", clashes)

# Chain merging: A and C only meet through B
print("\nChain test: contact A has number 1, C has number 2, B has both")
chain = [
    {"name": "A", "numbers": ["9111111111"]},
    {"name": "C", "numbers": ["9222222222"]},
    {"name": "B", "numbers": ["9111111111", "9222222222"]},
]
chain_result = merge_with_dictionary(chain)
print("  records:", len(chain_result), "-> numbers:", chain_result[0]["numbers"])
chain_ok = (len(chain_result) == 1 and len(chain_result[0]["numbers"]) == 2)

print("\nEmpty input:", merge_with_dictionary([]), " | only empty contacts:",
      merge_with_dictionary([{}, {"name": None}]))

# ---------------------------------------------------------------
# Generating large test data
# ---------------------------------------------------------------
FIRST = ["Ravi", "Priya", "Anita", "Suresh", "Meena", "Karthik", "Divya", "Arun",
         "Lakshmi", "Vijay", "Kavitha", "Mohan", "Deepa", "Rahul", "Sneha",
         "Ganesh", "Nithya", "Bala", "Revathi", "Senthil"]
LAST = ["Kumar", "Sharma", "Das", "Raj", "Iyer", "Nair", "Reddy", "Pillai", "Singh",
        "Patel", "Menon", "Rao", "Gupta", "Verma", "Joshi", "Naidu", "Murthy",
        "Khan", "Bose", "Shah"]


def write_number(number, style):
    if style == 0:
        return "+91 " + number[:5] + " " + number[5:]
    if style == 1:
        return number
    if style == 2:
        return "0" + number
    if style == 3:
        return "+91-" + number[:5] + "-" + number[5:]
    return number[:5] + " " + number[5:]


def write_name(first, last, style):
    full = first + " " + last
    if style == 0:
        return full
    if style == 1:
        return full.lower()
    if style == 2:
        return "Dr. " + full
    if style == 3:
        return full.upper()
    return first


def make_contacts(n, seed):
    """n contacts for n // 2 people. Returns (contacts, truth).
    truth[primary number] = (all numbers seen for that person, all e-mails seen)."""
    rng = random.Random(seed)
    people = n // 2
    pool = rng.sample(range(4000000000, 10000000000), people * 2)   # all different

    counts = [1] * people                       # every person has at least 1 contact
    for _ in range(n - people):
        counts[rng.randrange(people)] += 1      # the rest are duplicates

    contacts = []
    truth = {}
    for i in range(people):
        primary = str(pool[2 * i])
        secondary = str(pool[2 * i + 1])
        has_secondary = rng.random() < 0.3
        email = "user" + str(i) + "@mail.com"
        has_email = rng.random() < 0.4
        first = rng.choice(FIRST)
        last = rng.choice(LAST)          # many different people share a name

        numbers_seen = {primary}
        emails_seen = set()
        for _ in range(counts[i]):
            numbers = [write_number(primary, rng.randint(0, 4))]
            if has_secondary and rng.random() < 0.5:
                numbers.append(write_number(secondary, rng.randint(0, 4)))
                numbers_seen.add(secondary)
            emails = []
            if has_email and rng.random() < 0.6:
                emails.append(rng.choice([email, email.upper()]))
                emails_seen.add(email)
            name = None if rng.random() < 0.1 else write_name(first, last, rng.randint(0, 4))
            contacts.append({"source": rng.choice(["phone1", "phone2", "sim"]),
                             "name": name, "numbers": numbers, "emails": emails})
        truth[primary] = (numbers_seen, emails_seen)
    rng.shuffle(contacts)
    return contacts, truth


def verify(records, truth):
    """Check the merge against the known answer."""
    by_number = {}
    for r in records:
        for number in r["numbers"]:
            if number in by_number:
                return False                    # a number in two records
            by_number[number] = r
    for primary in truth:
        numbers_seen, emails_seen = truth[primary]
        r = by_number.get(primary)
        if r is None:
            return False
        if set(r["numbers"]) != numbers_seen or set(r["emails"]) != emails_seen:
            return False
    return len(records) == len(truth)


def best_time(function, contacts, repeats):
    best = None
    for _ in range(repeats):
        start = time.perf_counter()
        function(contacts)
        elapsed = time.perf_counter() - start
        if best is None or elapsed < best:
            best = elapsed
    return best


# ---------------------------------------------------------------
print("\n" + "=" * 70)
print("STAGE 3 - TEST 3: TIME FOR THE DICTIONARY DESIGN")
print("=" * 70)

print("%-9s %-8s %-9s %-11s %-13s %-9s" %
      ("contacts", "people", "records", "time (s)", "us/contact", "correct"))
dict_times = {}
all_correct = True
for n in [1000, 10000, 100000]:
    contacts, truth = make_contacts(n, seed=n)
    repeats = 5 if n <= 10000 else 3
    t = best_time(merge_with_dictionary, contacts, repeats)
    records = merge_with_dictionary(contacts)
    ok = verify(records, truth) and check_no_loss(contacts, records)
    all_correct = all_correct and ok
    dict_times[n] = t
    print("%-9d %-8d %-9d %-11.4f %-13.2f %-9s" %
          (len(contacts), len(truth), len(records), t, t / len(contacts) * 1e6, ok))

names_seen = set()
for r in records:
    names_seen.add(r["name"])
print("\nAt 100,000 contacts: %d records but only %d different display names,"
      % (len(records), len(names_seen)))
print("so many different people share a name - none of them were merged by name.")
per_contact_ratio = (dict_times[100000] / 100000) / (dict_times[1000] / 1000)
print("Speed check: time(100,000) / time(1,000) = %.0f (linear growth: about 100)"
      % (dict_times[100000] / dict_times[1000]))
print("Time per contact grew %.1f times for 100 times more data" % per_contact_ratio)
print("(a quadratic method would make it 100 times larger; the small rise here comes")
print(" from garbage collection and memory-cache effects, not from the algorithm)")

# ---------------------------------------------------------------
print("\n" + "=" * 70)
print("MEASUREMENT: COMPARING EVERY PAIR (alternative design)")
print("=" * 70)

print("%-9s %-14s %-12s %-12s %-10s %-9s" %
      ("contacts", "pairs", "pairs (s)", "dict (s)", "ratio", "same"))
pair_times = {}
for n in [1000, 2000, 4000, 8000]:
    contacts, truth = make_contacts(n, seed=n)
    t_pairs = best_time(merge_with_pairs, contacts, 1)
    t_dict = best_time(merge_with_dictionary, contacts, 5)
    same = merge_with_pairs(contacts) == merge_with_dictionary(contacts)
    pair_times[n] = t_pairs
    print("%-9d %-14d %-12.4f %-12.5f %-10.0f %-9s" %
          (n, n * (n - 1) // 2, t_pairs, t_dict, t_pairs / t_dict, same))

print("\nGrowth: time(2000)/time(1000) = %.1f, time(4000)/time(2000) = %.1f, "
      "time(8000)/time(4000) = %.1f"
      % (pair_times[2000] / pair_times[1000], pair_times[4000] / pair_times[2000],
         pair_times[8000] / pair_times[4000]))
print("(O(n^2) predicts 4.0 each time, O(n) predicts 2.0)")

big_pairs = 100000 * 99999 // 2
seconds_per_pair = pair_times[8000] / (8000 * 7999 // 2)
estimate = seconds_per_pair * big_pairs
print("\nESTIMATE (not measured) for 100,000 contacts with pair comparison:")
print("  pairs to compare : %d" % big_pairs)
print("  time per pair    : %.0f nanoseconds (from n = 8000)" % (seconds_per_pair * 1e9))
print("  estimated time   : %.0f seconds = %.1f minutes" % (estimate, estimate / 60))
print("  dictionary method (measured): %.3f seconds -> about %.0f times faster"
      % (dict_times[100000], estimate / dict_times[100000]))

# ---------------------------------------------------------------
print("\n" + "=" * 70)
print("MEASUREMENT: MEMORY (peak, tracemalloc)")
print("=" * 70)


def peak_memory(function, contacts):
    tracemalloc.start()
    function(contacts)
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    return peak


print("%-9s %-18s %-18s" % ("contacts", "dictionary peak", "pairs peak"))
for n in [1000, 4000]:
    contacts, truth = make_contacts(n, seed=n)
    m1 = peak_memory(merge_with_dictionary, contacts)
    m2 = peak_memory(merge_with_pairs, contacts)
    print("%-9d %-18d %-18d" % (n, m1, m2))

contacts, truth = make_contacts(100000, seed=100000)
m1 = peak_memory(merge_with_dictionary, contacts)
print("%-9d %-18d %-18s" % (100000, m1, "(not run)"))
print("Per contact at 100,000: about %.0f bytes for the dictionary design" % (m1 / 100000))

# ---------------------------------------------------------------
print("\n" + "=" * 70)
print("REQUIREMENT CHECKS")
print("=" * 70)
checks = [
    ("R1/R3 nothing lost, no number repeated (hand list and large lists)",
     check_no_loss(small, merged) and all_correct),
    ("R2 shared number/e-mail -> same record (hand list, chain test, ground truth)",
     hand_ok and chain_ok and all_correct),
    ("R4 all number formats give one key", all_same),
    ("R5 same name, different numbers -> separate records",
     len([r for r in merged if r["name"] == "Ravi Kumar"]) == 2),
    ("R6 missing/None/empty fields handled (13-contact hand list ran)", hand_ok),
    ("R7a 100,000 contacts in under 5 seconds", dict_times[100000] < 5),
    ("R7b time per contact grows under 5x for 100x more data",
     per_contact_ratio < 5),
]
for text, passed in checks:
    print("  [%s] %s" % ("PASS" if passed else "FAIL", text))