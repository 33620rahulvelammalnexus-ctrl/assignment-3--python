import random
import time
from collections import Counter



calls = [
    "seeds not received seeds delayed",
    "fertiliser price high",
    "seeds price high subsidy not received",
]

STOP = {"not", "high"}


def clean_words(text):
    """Lower-case the text, turn punctuation into spaces, split into words."""
    cleaned = ""
    for ch in text.lower():
        if ch.isalnum():
            cleaned += ch
        else:
            cleaned += " "
    return cleaned.split()


def frequencies(texts, stop):
    # TODO 1: dictionary word -> count for every word not in stop, using get()
    counts = {}
    for text in texts:
        for word in clean_words(text):
            if word not in stop:
                counts[word] = counts.get(word, 0) + 1
    return counts


def top(counts, k):
    # TODO 2: k most frequent (word, count) pairs, highest count first,
    #         alphabetical order for ties
    pairs = sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))
    return pairs[:k]


print("=" * 60)
print("PART A: COMPLETE THE CODE")
print("=" * 60)
print(top(frequencies(calls, STOP), 3))

# Why price comes before received: both have count 2, so the tie is broken
# alphabetically, and "price" < "received" because 'p' comes before 'r'.
print("Tie-break check: 'price' < 'received' is", "price" < "received")


print("\n" + "=" * 60)
print("PART B: IMPLEMENTATION TASKS")
print("=" * 60)


# 1. Counting with setdefault()
def frequencies_setdefault(texts, stop):
    counts = {}
    for text in texts:
        for word in clean_words(text):
            if word not in stop:
                counts.setdefault(word, 0)     # create the key with 0 if missing
                counts[word] += 1
    return counts


print("\n1. Word frequencies")
print("Using get()        :", frequencies(calls, STOP))
print("Using setdefault() :", frequencies_setdefault(calls, STOP))
print("Same result        :", frequencies(calls, STOP) == frequencies_setdefault(calls, STOP))

# 2. Group complaints by district (dictionary of lists)
complaints = [
    ("Chennai",    "paddy",     "seeds not received"),
    ("Madurai",    "cotton",    "pesticide price high"),
    ("Chennai",    "paddy",     "fertiliser price high"),
    ("Salem",      "sugarcane", "pump not working"),
    ("Madurai",    "paddy",     "water shortage"),
    ("Chennai",    "cotton",    "seeds delayed"),
]

by_district = {}
by_crop = {}
for district, crop, text in complaints:          # unpacking tuples in a loop
    by_district.setdefault(district, []).append(text)
    by_crop.setdefault(crop, []).append(text)

print("\n2. Complaints grouped by district")
for district, texts in by_district.items():
    print(district, "->", len(texts), "complaints:", texts)

print("\nComplaints grouped by crop")
for crop, texts in by_crop.items():
    print(crop, "->", texts)

print("\nNumber of complaints per district:")
counts_per_district = {}
for district in by_district:
    counts_per_district[district] = len(by_district[district])
print(counts_per_district)

# 3. Top k words with stop words removed
print("\n3. Top 3 words, stop words removed:")
print(top(frequencies(calls, STOP), 3))
print("Top 3 words, stop words NOT removed:")
print(top(frequencies(calls, set()), 3))

# 4. Order of keys and views (Python 3.7+)
print("\n4. Key order and views")
d = {}
d["zebra"] = 1
d["apple"] = 2
d["mango"] = 3
print("Keys keep INSERTION order:", list(d))

keys_view = d.keys()
values_view = d.values()
items_view = d.items()
print("keys()  :", keys_view)
print("values():", values_view)
print("items() :", items_view)
d["banana"] = 4
print("After adding 'banana', the SAME views show it (they are live):")
print("keys()  :", keys_view)
print("values():", values_view)
print("items() :", items_view)
print("\n" + "=" * 60)
print("PART C: EXPERIMENTAL INVESTIGATION")
print("=" * 60)

random.seed(1)

REAL_WORDS = ["seeds", "fertiliser", "price", "subsidy", "delayed", "received",
              "pump", "water", "pesticide", "loan", "insurance", "tractor",
              "rain", "market", "credit", "electricity", "soil", "harvest",
              "drought", "disease"]
COMMON_WORDS = ["not", "high", "the", "is", "a", "and", "my", "to", "of", "for"]
EXTRA_WORDS = ["term" + str(i) for i in range(80)]
VOCAB = REAL_WORDS + COMMON_WORDS + EXTRA_WORDS      # 110 words
BIG_STOP = set(COMMON_WORDS)


def make_complaints(n):
    texts = []
    for _ in range(n):
        length = random.randint(5, 10)
        words = []
        for _ in range(length):
            words.append(random.choice(VOCAB))
        texts.append(" ".join(words))
    return texts


def all_words(texts, stop):
    """One flat list of cleaned words with stop words removed."""
    words = []
    for text in texts:
        for w in clean_words(text):
            if w not in stop:
                words.append(w)
    return words


def count_dict(words):
    counts = {}
    for w in words:
        counts[w] = counts.get(w, 0) + 1
    return counts


def count_list(words):
    """list.count() for every distinct word: O(n * d)."""
    counts = {}
    for w in set(words):
        counts[w] = words.count(w)
    return counts


def count_counter(words):
    return Counter(words)


print("\n1. Timing the three counting methods (counting step only)")
print("%-10s %-10s %-9s %-12s %-12s %-12s" %
      ("complaints", "words n", "distinct d", "dict(s)", "list.count(s)", "Counter(s)"))

for n in [1000, 10000, 100000]:
    texts = make_complaints(n)
    words = all_words(texts, BIG_STOP)

    t = time.perf_counter()
    r1 = count_dict(words)
    t_dict = time.perf_counter() - t

    t = time.perf_counter()
    r2 = count_list(words)
    t_list = time.perf_counter() - t

    t = time.perf_counter()
    r3 = count_counter(words)
    t_counter = time.perf_counter() - t

    same = (r1 == r2) and (r1 == dict(r3))
    print("%-10d %-10d %-9d %-12.5f %-13.5f %-12.5f same=%s" %
          (n, len(words), len(r1), t_dict, t_list, t_counter, same))

# Effect of the number of distinct words d (n fixed)
print("\n2. Effect of d on list.count() (n = 20,000 words fixed)")
print("%-12s %-12s %-14s" % ("distinct d", "dict(s)", "list.count(s)"))
for d_count in [10, 100, 1000]:
    vocab = ["w" + str(i) for i in range(d_count)]
    words = []
    for _ in range(20000):
        words.append(random.choice(vocab))

    t = time.perf_counter()
    count_dict(words)
    t_dict = time.perf_counter() - t

    t = time.perf_counter()
    count_list(words)
    t_list = time.perf_counter() - t

    print("%-12d %-12.5f %-14.5f" % (d_count, t_dict, t_list))

# Edge-case tests
print("\n3. Edge-case tests (empty text, case, punctuation)")
tests = [
    ("empty text",         [""]),
    ("no texts at all",    []),
    ("only spaces",        ["   "]),
    ("upper/lower case",   ["Seeds SEEDS seeds"]),
    ("punctuation",        ["Seeds, seeds! seeds. (seeds)"]),
    ("only stop words",    ["Not HIGH, not."]),
    ("hyphen and digits",  ["price-high 2024 rate"]),
]
for name, texts in tests:
    result = frequencies(texts, STOP)
    print("%-18s %-35s -> %s" % (name, texts, result))

print("\ntop(empty dictionary, 3) ->", top({}, 3))
print("top(counts, 10) when fewer than 10 words ->",
      top(frequencies(calls, STOP), 10))
print("\n" + "=" * 60)
print("PART D: collections.Counter")
print("=" * 60)

counter = Counter(all_words(calls, STOP))
print("Counter           :", counter)
print("Counter.most_common(3):", counter.most_common(3))
print("(most_common sorts by count only; ties keep first-seen order.)")
print("Tie-safe top(counter, 3):", top(counter, 3))