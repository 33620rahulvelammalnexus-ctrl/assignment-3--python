import time

ai_elective = {"192311001", "192311004", "192311007", "192311009"}
iot_elective = {"192311002", "192311004", "192311009", "192311010"}
all_students = {f"1923110{i:02d}" for i in range(1, 11)}

both = ai_elective & iot_elective                       # intersection
exactly_one = ai_elective ^ iot_elective                # symmetric difference
neither = all_students - (ai_elective | iot_elective)   # difference of union

print("=== PART 1: Set operators ===")
print("clash      :", sorted(both))
print("exactly one:", sorted(exactly_one))
print("neither    :", sorted(neither))


both_m = ai_elective.intersection(iot_elective)
exactly_one_m = ai_elective.symmetric_difference(iot_elective)
neither_m = all_students.difference(ai_elective.union(iot_elective))

print("\n=== PART 2: Set methods ===")
print("clash      :", sorted(both_m))
print("exactly one:", sorted(exactly_one_m))
print("neither    :", sorted(neither_m))
print("Same results?", both == both_m and exactly_one == exactly_one_m and neither == neither_m)


raw_ai = ["192311001", "192311004", "192311004", "192311007", "192311009", "192311001"]
clean_ai = set(raw_ai)

print("\n=== PART 3: Duplicate removal ===")
print("Before:", len(raw_ai), "registrations")
print("After :", len(clean_ai), "unique students")
print("Sorted:", sorted(clean_ai))


def report(a, b):
    print("  clash      :", sorted(a & b))
    print("  exactly one:", sorted(a ^ b))
    print("  neither    :", sorted(all_students - (a | b)))

print("\n=== PART 4: Edge cases ===")
print("Both electives empty:")
report(set(), set())
print("One elective empty:")
report(ai_elective, set())
print("Identical electives:")
report(ai_elective, ai_elective)


print("\n=== PART 5: Hand verification ===")
A = {1, 4, 7, 9}
B = {2, 4, 9, 10}
U = set(range(1, 11))
print("A & B        =", sorted(A & B), "(expected [4, 9])")
print("A | B        =", sorted(A | B), "(expected [1, 2, 4, 7, 9, 10])")
print("A ^ B        =", sorted(A ^ B), "(expected [1, 2, 7, 10])")
print("U - (A | B)  =", sorted(U - (A | B)), "(expected [3, 5, 6, 8])")
print("Formula |A|+|B|-|A&B| =", len(A) + len(B) - len(A & B), "= |A|B| =", len(A | B))


print("\n=== PART 6: x in list vs x in set ===")
for n in [10000, 100000, 1000000]:
    data_list = [str(192000000 + i) for i in range(n)]
    data_set = set(data_list)
    x = data_list[-1]            # worst case for the list

    repeats = 20
    start = time.perf_counter()
    for _ in range(repeats):
        found = x in data_list
    list_time = (time.perf_counter() - start) / repeats

    start = time.perf_counter()
    for _ in range(repeats):
        found = x in data_set
    set_time = (time.perf_counter() - start) / repeats

    print(f"n = {n:>8} | list: {list_time:.8f} s | set: {set_time:.8f} s")


print("\n=== PART 7: Nested loops vs set & ===")
for n in [500, 1000, 2000]:
    list_a = [str(i) for i in range(n)]
    list_b = [str(i) for i in range(n // 2, n + n // 2)]   # half overlap

    start = time.perf_counter()
    common_loop = []
    for a in list_a:
        for b in list_b:
            if a == b:
                common_loop.append(a)
    loop_time = time.perf_counter() - start

    start = time.perf_counter()
    common_set = set(list_a) & set(list_b)
    set_time = time.perf_counter() - start

    print(f"n = {n:>5} | nested loops: {loop_time:.6f} s | set &: {set_time:.6f} s | same: {sorted(common_loop) == sorted(common_set)}")


def common_sorted(list_a, list_b):
    a = sorted(list_a)
    b = sorted(list_b)
    i = 0
    j = 0
    result = []
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            result.append(a[i])
            i += 1
            j += 1
        elif a[i] < b[j]:
            i += 1
        else:
            j += 1
    return result

print("\n=== PART 8: Sort and walk ===")
ai_list = ["192311001", "192311004", "192311007", "192311009"]
iot_list = ["192311002", "192311004", "192311009", "192311010"]
print("Common (sort + walk):", common_sorted(ai_list, iot_list))


print("\n=== PART 9: Lists vs tuples in sets ===")
print("Set with tuples:", {(1, 2), (3, 4)})
try:
    bad = {[1, 2], [3, 4]}
except TypeError as e:
    print("Set with lists -> TypeError:", e)